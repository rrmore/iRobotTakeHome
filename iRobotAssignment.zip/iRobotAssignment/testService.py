import unittest
import spoonacular as sp
import os
from src.services import  Services

class TestSum(unittest.TestCase):

    def test_APITokenExist(self):
        API_TOKEN = os.getenv('API_TOKEN')
        self.assertNotEqual(API_TOKEN, None)
        
    def test_validMostPopularRecipeByIngredients(self):
        api = Services()
        response = api.mostPopularRecipeByIngredients('apples')
        self.assertEqual(type(response), dict)

    def test_emptyMostPopularRecipeByIngredients(self):
        api = Services()
        response = api.mostPopularRecipeByIngredients('    ')
        self.assertEqual(len(response), 0)

    def test_inValidMostPopularRecipeByIngredients(self):
        api = Services()
        response = api.mostPopularRecipeByIngredients('23213')
        self.assertEqual(len(response), 0)
        

if __name__ == "__main__":
    unittest.main()
