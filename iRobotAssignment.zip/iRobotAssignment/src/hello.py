import os
from services import Services

#API_TOKEN = os.environ["API_TOKEN"]

user_input = input("Enter ingredient to search recipe e.g. apples,flour: ")

#sanitize user input incase they pass ingredent with space
user_input = user_input.replace(' ', ',')

#calling service
services = Services()
most_popular_recipe = services.mostPopularRecipeByIngredients(user_input)

if most_popular_recipe:
    if most_popular_recipe.get('message') == None:
        missed_ingredients_count = most_popular_recipe['missedIngredientCount']
        missed_ingredients = most_popular_recipe['missedIngredients']
        missed_ingredients_list = [i['originalName'] for i in missed_ingredients]

        used_ingredients_count = most_popular_recipe['usedIngredientCount']
        used_ingredients = most_popular_recipe['usedIngredients']

        print("Most popular recipe name: ", most_popular_recipe['title'])
        print("Likes received to this recipe: ", most_popular_recipe['likes'])
        print("Missing Ingredient for the recipe: ", missed_ingredients_list)
    else:
        print("Please verify API Token passed:" + most_popular_recipe.get('message'))
else:
    print("No recipe found for the given ingredient. Run the program again")
