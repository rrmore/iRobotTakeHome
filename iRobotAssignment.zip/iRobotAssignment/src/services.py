import os
import spoonacular as sp

class Services(object):
        
    def __init__(self):
        self.api = sp.API(os.getenv('API_TOKEN'))
        
    def mostPopularRecipeByIngredients(self, ingredients):
        '''
        Parameters: ingredients separated by comma e.g. 'apples, flour'
        Returns: most liked recipe
        '''
        response = self.api.search_recipes_by_ingredients(ingredients)
        data = response.json()
        
        #business logic to filter recipe
        if type(data) == list and len(data) > 0:
            likes_array = [i['likes'] for i in data]
            most_liked_index = likes_array.index(max(likes_array))
            return data[most_liked_index]
        else:
            return data
